import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const data = JSON.parse(read('src/quiz-data.json'));
const config = JSON.parse(read('src/config.json'));
const pageIds = new Set(data.pages.map(page => page.id));
if (!pageIds.has(data.startPageId)) throw new Error('Etapa inicial inválida.');
const assets = {};
for (const page of data.pages) {
  for (const item of page.data.elements) {
    for (const target of [item.targetNodeId, ...(item.content?.options || []).map(option => option.targetNodeId)].filter(Boolean)) {
      if (target !== 'checkout' && !pageIds.has(target)) throw new Error(`Destino inexistente: ${target}`);
    }
    const id = item.content?.image?.providerId;
    if (id && !assets[id]) {
      fs.accessSync(path.join(root, 'assets', `${id}.avif`), fs.constants.R_OK);
      assets[id] = `./assets/${id}.avif`;
    }
  }
}
fs.accessSync(path.join(root, 'assets/red-hat-display.woff2'), fs.constants.R_OK);
// O CSS fica dentro do HTML: os caminhos são relativos a index.html.
const css = read('src/styles.css').replace('../assets/red-hat-display.woff2', './assets/red-hat-display.woff2');
// Escapar '<' impede que conteúdo editorial encerre uma tag script.
const json = value => JSON.stringify(value).replace(/</g, '\\u003c');
const html = read('src/template.html')
  .replace('/* STYLES */', () => css)
  .replace('/* CONFIG */', () => JSON.stringify(config, null, 2).replace(/</g, '\\u003c'))
  .replace('/* DATA */', () => json(data))
  .replace('/* ASSETS */', () => json(assets))
  .replace('/* APP */', () => read('src/app.js'));
fs.writeFileSync(path.join(root, 'index.html'), html, 'utf8');
console.log(`index.html criado: ${(Buffer.byteLength(html) / 1024).toFixed(1)} KB, ${data.pages.length} telas incluindo ramificações, ${Object.keys(assets).length} imagens referenciadas na pasta assets/.`);
