(() => {
  "use strict";

  const CONFIG = JSON.parse(document.getElementById("quiz-config").textContent);
  const DATA = JSON.parse(document.getElementById("quiz-data").textContent);
  const ASSETS = JSON.parse(document.getElementById("quiz-assets").textContent);
  const pages = new Map(DATA.pages.map(page => [page.id, page]));
  const quiz = document.getElementById("quiz");
  const announcement = document.getElementById("announcement");
  const dialog = document.getElementById("message-dialog");
  const storageKey = "aimodelab-quiz-html-v1";
  const defaults = () => ({ pageId: DATA.startPageId, name: "", answers: {}, history: [] });
  let state = defaults();
  let timer = null;
  let transitionLocked = false;
  let confirmAction = null;

  // O progresso e o nome ficam apenas nesta aba. Nada é enviado a um servidor.
  if (CONFIG.rememberProgress) {
    try {
      const saved = JSON.parse(sessionStorage.getItem(storageKey));
      if (saved && pages.has(saved.pageId) && typeof saved.name === "string") {
        state = {
          pageId: saved.pageId,
          name: saved.name.slice(0, 80),
          answers: saved.answers && typeof saved.answers === "object" ? saved.answers : {},
          history: Array.isArray(saved.history) ? saved.history.filter(id => pages.has(id)).slice(-50) : []
        };
      }
    } catch { /* file:// ou armazenamento bloqueado: o quiz continua em memória. */ }
  }

  function persist() {
    if (!CONFIG.rememberProgress) return;
    try { sessionStorage.setItem(storageKey, JSON.stringify(state)); } catch { /* Opcional. */ }
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
  }

  // Somente a marcação editorial conhecida é aceita. O nome nunca vira HTML.
  function richHTML(value = "") {
    const template = document.createElement("template");
    template.innerHTML = String(value).replace(/\{\{nome\}\}/g, () => escapeHTML(state.name || "amigo/a"));
    const allowed = new Set(["P", "BR", "STRONG", "B", "EM", "I", "U", "SPAN", "UL", "OL", "LI"]);
    for (const element of [...template.content.querySelectorAll("*")]) {
      if (!allowed.has(element.tagName)) { element.replaceWith(document.createTextNode(element.textContent)); continue; }
      const color = element.style.color;
      for (const attr of [...element.attributes]) element.removeAttribute(attr.name);
      if (color) element.style.color = color;
    }
    return template.innerHTML;
  }

  function element(tag, className, html) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (html !== undefined) node.innerHTML = richHTML(html);
    return node;
  }

  function theme(node, style = {}) {
    if (style.primaryColor) node.style.setProperty("--primary", style.primaryColor);
    if (style.secondaryColor) node.style.setProperty("--secondary", style.secondaryColor);
    if (style.textAlign) node.style.textAlign = style.textAlign;
    if (style.width && style.width < 100) {
      node.dataset.width = style.width;
      node.style.setProperty("--element-width", `${style.width}%`);
      node.style.setProperty("--width-gap", 1 - style.width / 100);
    }
    return node;
  }

  function validateName() {
    const input = quiz.querySelector(".name-input");
    if (!input) return true;
    const name = input.value.trim().replace(/\s+/g, " ");
    const valid = name.length > 0 && name.length <= 80;
    input.setAttribute("aria-invalid", String(!valid));
    document.getElementById("name-error").hidden = valid;
    if (!valid) { input.focus(); return false; }
    state.name = name;
    persist();
    return true;
  }

  function navigate(target, answer, replacePage = false) {
    if (transitionLocked || !validateName()) return;
    if (target === "checkout") { openCheckout(); return; }
    if (!pages.has(target)) return;
    transitionLocked = true;
    if (answer) state.answers[answer.id] = answer.value;
    if (!replacePage) state.history.push(state.pageId);
    state.pageId = target;
    persist();
    render(true);
    // Impede que um toque duplo pule duas telas.
    setTimeout(() => { transitionLocked = false; }, 250);
  }

  function showDialog(title, description, action) {
    document.getElementById("dialog-title").textContent = title;
    document.getElementById("dialog-description").textContent = description;
    document.getElementById("dialog-confirm").textContent = "Entendido";
    document.getElementById("dialog-cancel").hidden = !action;
    confirmAction = action || null;
    dialog.showModal();
  }

  function openCheckout() {
    let url;
    try {
      url = new URL(CONFIG.checkoutUrl);
      if (url.protocol !== "https:") throw new Error("HTTPS requerido");
    } catch {
      showDialog("Inscripciones no disponibles", "Las inscripciones no están disponibles por el momento. Puedes volver a revisar el contenido del quiz.");
      return;
    }
    // Transfere somente parâmetros de campanha; não envia nome nem respostas.
    if (CONFIG.passCampaignParameters) {
      const accepted = /^(utm_(source|medium|campaign|term|content|id)|gclid|fbclid|ttclid|src|sck)$/;
      for (const [key, value] of new URLSearchParams(location.search)) {
        if (accepted.test(key) && value.length <= 500 && !url.searchParams.has(key)) url.searchParams.set(key, value);
      }
    }
    location.assign(url.href);
  }

  function renderElement(item, page) {
    const content = item.content || {};
    const style = item.theme || {};
    let node;
    switch (item.type) {
      case "image": {
        const imageData = content.image;
        if (!imageData || !ASSETS[imageData.providerId]) return null;
        node = element("div", "image-element");
        const img = document.createElement("img");
        img.src = ASSETS[imageData.providerId];
        img.alt = /Logo/i.test(imageData.name) ? "The AI Model Lab" : (imageData.alt || "Ejemplo de modelo virtual creado con inteligencia artificial");
        img.width = imageData.width;
        img.height = imageData.height;
        img.decoding = "async";
        // Caminhos relativos à pasta assets/, ao lado de index.html.
        node.append(img);
        break;
      }
      case "title":
        node = element(quiz.querySelector("h1") ? "h2" : "h1", "title", content.text);
        node.tabIndex = -1;
        break;
      case "text":
        node = element("div", "rich-text", content.text);
        break;
      case "progress": {
        node = element("div", "progress-element");
        const track = element("div", "progress-track");
        track.setAttribute("role", "progressbar");
        track.setAttribute("aria-label", "Progreso del quiz");
        track.setAttribute("aria-valuemin", "0");
        track.setAttribute("aria-valuemax", "100");
        track.setAttribute("aria-valuenow", page.progress);
        const fill = element("div", "progress-fill");
        fill.style.width = `${page.progress}%`;
        track.append(fill);
        const percent = element("span", "progress-number");
        percent.textContent = `${page.progress}%`;
        node.append(track, percent);
        break;
      }
      case "inputText": {
        node = element("div", "input-element");
        const label = element("label", "input-label sr-only");
        label.htmlFor = "visitor-name";
        label.textContent = "Tu nombre";
        const input = element("input", "name-input");
        input.id = "visitor-name";
        input.name = "name";
        input.type = "text";
        input.autocomplete = "given-name";
        input.maxLength = 80;
        input.required = content.required !== false;
        input.placeholder = content.placeholder || "Escribe tu nombre aquí...";
        input.value = state.name;
        input.setAttribute("aria-describedby", content.helperText ? "name-error name-help" : "name-error");
        const error = element("p", "input-error");
        error.id = "name-error";
        error.textContent = "Escribe tu nombre para continuar.";
        error.setAttribute("role", "alert");
        error.hidden = true;
        const help = element("p", "input-help");
        help.id = "name-help";
        help.innerHTML = richHTML(content.helperText || "");
        help.hidden = !content.helperText;
        input.addEventListener("input", () => {
          state.name = input.value.slice(0, 80);
          input.removeAttribute("aria-invalid");
          error.hidden = true;
          persist();
        });
        node.append(label, input, error, help);
        break;
      }
      case "button":
        node = element("button", "primary-button", content.text);
        node.type = quiz.querySelector(".name-input") ? "submit" : "button";
        node.dataset.target = item.targetNodeId;
        if (item.settings?.animation === "pulse") {
          node.classList.add("pulse");
          // A face se move, mas a área clicável do botão permanece estável.
          const face = element("span", "button-face");
          face.append(...node.childNodes);
          node.append(face);
        }
        if (node.type !== "submit") node.addEventListener("click", () => navigate(item.targetNodeId));
        break;
      case "quiz":
      case "quizText": {
        node = element("div", "options");
        node.setAttribute("role", "group");
        node.setAttribute("aria-label", "Elige una respuesta");
        for (const option of content.options || []) {
          const button = element("button", "option");
          button.type = "button";
          button.style.setProperty("--option-bg", style.backgroundColor || "#20bf00");
          const selected = state.answers[item.id] === option.id;
          button.setAttribute("aria-pressed", String(selected));
          const marker = element("span", "option-marker");
          marker.textContent = selected ? "✓" : "";
          marker.setAttribute("aria-hidden", "true");
          const text = element("span", "option-text", option.text);
          const arrow = element("span", "option-arrow");
          arrow.textContent = "›";
          arrow.setAttribute("aria-hidden", "true");
          button.append(marker, text, arrow);
          button.addEventListener("click", () => navigate(option.targetNodeId, { id: item.id, value: option.id }));
          node.append(button);
        }
        break;
      }
      case "warranty":
      case "note": {
        node = element("section", "note");
        if (style.backgroundColor) node.style.setProperty("--note-bg", style.backgroundColor);
        if (style.textColor) node.style.setProperty("--note-color", style.textColor);
        const title = element(quiz.querySelector("h1") ? "h2" : "h1", "", content.title);
        title.tabIndex = -1;
        const description = element("div", "", content.description ?? content.text);
        node.append(title, description);
        break;
      }
      case "price": {
        node = element("section", "price-card");
        const title = element("p", "price-title");
        title.textContent = content.title || "OFERTA ESPECIAL";
        const subtitle = element("p", "price-subtitle");
        subtitle.textContent = content.subtitle;
        const price = element("strong", "price-value");
        price.textContent = CONFIG.price || content.price;
        const currency = element("span", "price-currency");
        currency.textContent = CONFIG.currency || "USD";
        node.append(title, subtitle, price, currency);
        break;
      }
      case "loading": {
        node = element("div", "loading-element");
        const ring = element("div", "loading-ring");
        ring.setAttribute("aria-hidden", "true");
        const number = element("span", "loading-number");
        number.textContent = "0%";
        ring.append(number);
        const title = element("h1", "title", content.text);
        title.tabIndex = -1;
        node.append(ring, title);
        break;
      }
      case "redirect": return null;
      default: return null;
    }
    node.classList.add("element");
    node.dataset.elementId = item.id;
    node.dataset.type = item.type;
    return theme(node, style);
  }

  function startLoading(page) {
    const redirect = page.data.elements.find(item => item.type === "redirect");
    if (!redirect) return;
    const seconds = Math.max(1, Number(CONFIG.loadingSeconds) || 5);
    const started = performance.now();
    timer = setInterval(() => {
      const progress = Math.min(100, Math.round((performance.now() - started) / (seconds * 10)));
      const ring = quiz.querySelector(".loading-ring");
      if (ring) {
        ring.style.setProperty("--loading", `${progress * 3.6}deg`);
        ring.querySelector(".loading-number").textContent = `${progress}%`;
      }
      if (progress >= 100) { clearInterval(timer); timer = null; navigate(redirect.targetNodeId, undefined, true); }
    }, 50);
  }

  function render(moveFocus = false) {
    clearInterval(timer);
    timer = null;
    const page = pages.get(state.pageId);
    quiz.replaceChildren();
    quiz.dataset.pageId = page.id;
    quiz.dataset.progress = page.progress;
    for (const item of page.data.elements) {
      const node = renderElement(item, page);
      if (node) quiz.append(node);
    }
    announcement.textContent = `Progreso: ${page.progress}%. ${quiz.querySelector("h1")?.textContent || ""}`;
    if (moveFocus) {
      window.scrollTo({ top: 0, behavior: "instant" });
      quiz.querySelector("h1")?.focus({ preventScroll: true });
    }
    startLoading(page);
  }

  quiz.addEventListener("submit", event => {
    event.preventDefault();
    const button = quiz.querySelector('button[type="submit"][data-target]');
    if (button) navigate(button.dataset.target);
  });
  document.getElementById("dialog-confirm").addEventListener("click", () => {
    const action = confirmAction;
    confirmAction = null;
    dialog.close();
    action?.();
  });
  document.getElementById("dialog-cancel").addEventListener("click", () => dialog.close());
  dialog.addEventListener("close", () => { confirmAction = null; });
  render();
})();
